import pymysql
import sys

# ==========================================
# KONFIGURASI DATABASE
# Sesuaikan dengan server MySQL lokal Anda
# ==========================================
DB_HOST = 'localhost'
DB_USER = 'root'
DB_PASSWORD = 'root' # Isi dengan password root Anda
DB_NAME = 'INVENTORY' # Menggunakan database INVENTORY dari file SQL

class DatabaseHelper:
    def __init__(self):
        self.connection = None
        self.connect()

    def connect(self):
        try:
            # Connect directly to the database assuming it's already imported
            self.connection = pymysql.connect(
                host=DB_HOST,
                user=DB_USER,
                password=DB_PASSWORD,
                database=DB_NAME,
                cursorclass=pymysql.cursors.DictCursor
            )
        except Exception as e:
            print(f"Error connecting to MySQL: {e}\nPastikan database 'INVENTORY' sudah dibuat dan SQL dump di-import.")
            sys.exit(1)

    def execute_query(self, query, params=None):
        cursor = self.connection.cursor()
        cursor.execute(query, params)
        self.connection.commit()
        return cursor

    def fetch_all(self, query, params=None):
        cursor = self.connection.cursor()
        cursor.execute(query, params)
        return cursor.fetchall()
